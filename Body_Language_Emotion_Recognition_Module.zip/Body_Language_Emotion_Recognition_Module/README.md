# Body_Language_Emotion_Recognition_Module

[KNN NoteBook Link on Colab](https://colab.research.google.com/drive/13_bV0a0GCzifNz3m90SyyyX2tTaSIACH?usp=sharing)  
[SVM NoteBook Link on Colab](https://colab.research.google.com/drive/110qKVnsea-BzOylq976bQYmjwxrquAXQ?usp=sharing)


