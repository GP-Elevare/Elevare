# MEED Dataset - Multi-view Emotional Expressions Dataset

The **MEED (Multi-view Emotional Expressions Dataset)** is a dataset for **human emotion recognition** based on **facial and body landmarks**. It contains multi-view recordings of actors expressing **seven distinct emotions**.

## 📄 Dataset Description

The MEED dataset provides:

- **Pose landmarks**: X/Y coordinates of keypoints for body and face  
- **Emotion labels**: Encoded in filenames  
- **Multi-view recordings**: Each expression is captured from multiple camera angles  
- **Scenario information**: Different scenarios and repetitions per actor  

It is widely used for **emotion recognition tasks** with machine learning models like KNN, SVM, and XGBoost. Features such as **distances, angles, and keypoint relationships** can be extracted from the pose landmarks for model training.


## 📂 Dataset Structure

Files are named using the pattern:


### Example Filename


- `front` → Camera view (front, left, right)  
- `F02` → Actor ID  
- `SU` → Emotion code  
- `001` → Scenario or repetition number  

### Emotion Codes

| Code | Emotion     |
|------|------------|
| A    | Anger      |
| D    | Disgust    |
| F    | Fear       |
| H    | Happiness  |
| N    | Neutral    |
| SA   | Sadness    |
| SU   | Surprise   |


## 🔗 Dataset Link

Access the MEED dataset here:  
[MEED Dataset - Official](https://github.com/Paul-Li-MIT/MEED)
